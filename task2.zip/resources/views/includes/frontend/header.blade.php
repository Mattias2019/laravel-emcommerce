<header>
  @include( 'frontend-templates.header.' .$appearance_settings['header']. '.' .$appearance_settings['header'] )
</header>