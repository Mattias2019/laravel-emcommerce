<?php
namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class RequestProduct extends Model
{  
  protected $table = 'request_products';
 
}