<?php

namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class VendorAnnouncement extends Model
{
  protected $table = 'vendor_announcements';
}
