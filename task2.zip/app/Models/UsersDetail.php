<?php
namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class UsersDetail extends Model
{
  protected $table = 'users_details';
}
