<?php
namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class Term extends Model
{
  protected $table = 'terms';
}
