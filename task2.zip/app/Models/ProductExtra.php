<?php
namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class ProductExtra extends Model
{
   
  protected $table = 'product_extras';
}
